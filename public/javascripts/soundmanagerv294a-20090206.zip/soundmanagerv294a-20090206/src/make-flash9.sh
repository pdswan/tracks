#!/bin/bash
/Applications/flexsdk/bin/mxmlc -use-network=true -o ../swf/soundmanager2_flash9.swf -file-specs "SoundManager2_AS3.as"